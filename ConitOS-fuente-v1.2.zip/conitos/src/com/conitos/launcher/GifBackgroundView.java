package com.conitos.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.os.SystemClock;
import android.view.View;

import java.io.ByteArrayInputStream;
import java.io.File;

/**
 * Fondo de pantalla GIF animado (sin dependencias externas, usa Movie del
 * SDK). Se dibuja en bucle con recorte tipo "centerCrop" para cubrir toda la
 * pantalla.
 */
public class GifBackgroundView extends View {

    private final Movie movie;
    private long startMs = 0;
    private float scale = 1f;
    private float dx = 0f, dy = 0f;

    public GifBackgroundView(Context c, File f) {
        super(c);
        Movie m = null;
        try {
            byte[] data = readAll(f);
            if (data.length > 0) m = Movie.decodeStream(new ByteArrayInputStream(data));
        } catch (Throwable t) {
            m = null;
        }
        movie = m;
    }

    /** true si el GIF se decodificó y puede dibujarse. */
    public boolean isOk() { return movie != null; }

    public int gifWidth() { return movie != null ? movie.width() : 0; }
    public int gifHeight() { return movie != null ? movie.height() : 0; }

    /** Primer fotograma como imagen fija (fallback si el GIF no anima). */
    public Bitmap firstFrame() {
        if (movie == null || movie.width() <= 0 || movie.height() <= 0) return null;
        try {
            Bitmap bmp = Bitmap.createBitmap(movie.width(), movie.height(), Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(bmp);
            movie.setTime(0);
            movie.draw(cv, 0, 0);
            return bmp;
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (movie == null || w <= 0 || h <= 0 || movie.width() <= 0 || movie.height() <= 0) return;
        float sx = (float) w / movie.width();
        float sy = (float) h / movie.height();
        scale = Math.max(sx, sy);              // centerCrop: cubre toda la pantalla
        dx = (w - movie.width() * scale) / 2f;
        dy = (h - movie.height() * scale) / 2f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (movie == null) return;
        long now = SystemClock.uptimeMillis();
        if (startMs == 0) startMs = now;
        int dur = movie.duration();
        if (dur <= 0) dur = 1000;              // GIF de un solo frame: se repite igual
        movie.setTime((int) ((now - startMs) % dur));
        canvas.save();
        canvas.translate(dx, dy);
        canvas.scale(scale, scale);
        movie.draw(canvas, 0, 0);
        canvas.restore();
        invalidate();                          // bucle continuo
    }

    private static byte[] readAll(File f) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            return bos.toByteArray();
        } catch (Throwable t) {
            return new byte[0];
        }
    }
}
