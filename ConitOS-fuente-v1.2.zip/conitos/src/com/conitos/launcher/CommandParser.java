package com.conitos.launcher;

import java.util.HashMap;
import java.util.Map;

/** Parser de comandos de voz simples (sin IA): español rioplatense. */
public class CommandParser {

    public static final int T_UNKNOWN = 0, T_TIME = 1, T_WEATHER = 2, T_VOL_UP = 3, T_VOL_DOWN = 4,
            T_MUTE = 5, T_BRIGHT_UP = 6, T_BRIGHT_DOWN = 7, T_REBOOT = 8, T_POWER = 9,
            T_SETTINGS = 10, T_LAUNCH = 11, T_HOME = 12;

    public static class Cmd {
        public int type = T_UNKNOWN;
        public String arg;
    }

    private static final Map<String, String> DICT = new HashMap<>();

    static {
        DICT.put("youtube", "com.google.android.youtube");
        DICT.put("yt", "com.google.android.youtube");
        DICT.put("netflix", "com.netflix.mediaclient");
        DICT.put("kodi", "org.xbmc.kodi");
        DICT.put("chrome", "com.android.chrome");
        DICT.put("play store", "com.android.vending");
        DICT.put("google play", "com.android.vending");
        DICT.put("configuracion", "@syssettings");
        DICT.put("ajustes", "@syssettings");
        DICT.put("settings", "@syssettings");
    }

    public static Cmd parse(String raw) {
        String s = UiUtil.norm(raw);
        Cmd c = new Cmd();
        if (s.isEmpty()) return c;

        // Hora
        if (s.contains("hora")) { c.type = T_TIME; return c; }

        // Clima
        if (s.contains("clima") || s.contains("temperatura") || s.contains("tiempo") || s.contains("grados")) {
            c.type = T_WEATHER;
            return c;
        }

        // Volumen
        if (s.contains("volumen") || s.contains("mute") || s.contains("mudo") || s.contains("silencio")) {
            if (s.contains("mute") || s.contains("mudo") || s.contains("silencio")
                    || ((s.contains("apaga") || s.contains("quita")) && s.contains("volumen"))) {
                c.type = T_MUTE;
            } else if (s.contains("baja") || s.contains("menos") || s.contains("abajo")) {
                c.type = T_VOL_DOWN;
            } else {
                c.type = T_VOL_UP;
            }
            return c;
        }

        // Brillo / luz
        if (s.contains("brillo") || (s.contains("luz") && s.contains("pantalla"))) {
            if (s.contains("baja") || s.contains("menos") || s.contains("abajo") || s.contains("oscuro")) {
                c.type = T_BRIGHT_DOWN;
            } else {
                c.type = T_BRIGHT_UP;
            }
            return c;
        }

        // Reiniciar
        if (s.contains("reinicia") || s.contains("reboot") || s.contains("restart") || s.contains("renicia")) {
            c.type = T_REBOOT;
            return c;
        }

        // Apagar
        if (s.contains("apaga") || s.contains("apagar") || s.contains("power off") || s.contains("prender de cero")) {
            c.type = T_POWER;
            return c;
        }

        // Abrir app
        String t = stripVerbs(s);
        if (t.isEmpty()) { c.type = T_HOME; return c; }
        String dp = DICT.get(t);
        if (dp != null) {
            if ("@syssettings".equals(dp)) {
                c.type = T_SETTINGS;
            } else {
                c.type = T_LAUNCH;
                c.arg = dp;
            }
            return c;
        }
        c.type = T_LAUNCH;
        c.arg = t;
        return c;
    }

    private static String stripVerbs(String s) {
        String[] prefixes = {
                "abri", "abre", "abrir", "poneme", "pone", "pon", "inicia", "iniciar",
                "ejecuta", "ejecutar", "lanza", "lanzar", "lanzame", "reproduc", "reproduce",
                "quiero ver", "quiero mirar", "quiero", "dame", "mostrame", "pasame",
                "cambia a", "cambia", "ir a", "ir", "activa", "activar"
        };
        String t = s;
        boolean changed = true;
        while (changed && !t.isEmpty()) {
            changed = false;
            for (String p : prefixes) {
                if (t.startsWith(p + " ")) { t = t.substring(p.length() + 1).trim(); changed = true; }
                else if (t.equals(p)) { t = ""; changed = true; }
            }
        }
        String[] filler = {"el", "la", "los", "las", "un", "una", "de", "del", "en", "al",
                "app", "aplicacion", "aplicaciones", "por favor"};
        changed = true;
        while (changed && !t.isEmpty()) {
            changed = false;
            for (String p : filler) {
                if (t.startsWith(p + " ")) { t = t.substring(p.length() + 1).trim(); changed = true; }
                else if (t.endsWith(" " + p)) { t = t.substring(0, t.length() - p.length() - 1).trim(); changed = true; }
                else if (t.equals(p)) { t = ""; changed = true; }
            }
        }
        return t;
    }
}
