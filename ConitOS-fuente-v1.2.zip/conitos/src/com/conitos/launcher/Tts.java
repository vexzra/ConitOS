package com.conitos.launcher;

import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Síntesis de voz (TTS) como singleton compartido entre la pantalla principal
 * y Ajustes. Es tolerante a fallos:
 *
 *  · Arranca con el motor del sistema y, si falla o no hay motor configurado,
 *    prueba con motores conocidos instalados (Google TTS, Pico, eSpeak).
 *  · Elige el idioma español con cadena de reemplazo (es-AR → es-MX → es-US →
 *    es-ES → es-419 → es → idioma del sistema) en vez de quedarse mudo si el
 *    motor no tiene español argentino.
 *  · Voz de mujer o de hombre (estilo Loquendo): primero busca una voz del
 *    motor cuyo nombre lo indique; si el motor no publica voces por género,
 *    ajusta el tono (agudo/grave) para que la diferencia se escuche igual.
 *  · Si se pide hablar antes de que el motor termine de inicializar, guarda el
 *    texto pendiente y lo dice apenas esté listo (antes se perdía).
 *  · Si la salida multimedia está en volumen 0 pero el sistema no, envía el
 *    audio por el stream del sistema (pasa en varias TV Box).
 */
public final class Tts {

    private static final Tts INSTANCE = new Tts();

    public static Tts get() { return INSTANCE; }

    private Tts() {}

    /** Motores TTS conocidos, por si el predeterminado no está configurado. */
    private static final String[] FALLBACK_ENGINES = {
            "com.google.android.tts",       // Síntesis de voz de Google
            "com.svox.pico",                // Pico TTS (viene en muchas box)
            "com.googlecode.eyesfree.espeak" // eSpeak
    };

    /** Nombres de voz de mujer / hombre usados por los motores (heurística). */
    private static final Pattern FEMALE_NAME = Pattern.compile(
            "female|fem|mujer|esperanza|m[oó]nica|paulina|helena|luciana|isabela|sabina"
                    + "|pen[eé]lope|elvira|francisca|ximena|camila|valentina|sof[ií]a"
                    + "|[áa]ngela|salom[eé]|d[aá]masa|avril|marisol|conchita", Pattern.CASE_INSENSITIVE);
    private static final Pattern MALE_NAME = Pattern.compile(
            "male|hombre|jorge|diego|carlos|juan|gonzalo|pablo|and[eé]s|t[oó]mas|mateo"
                    + "|lorenzo|javier|luc[aá]s|rodrigo|miguel|ra[uú]l|arnau", Pattern.CASE_INSENSITIVE);

    private TextToSpeech tts;
    private Context appCtx;
    private Prefs prefs;
    private boolean ready = false;
    private boolean exhausted = false;
    private int engineIdx = 0;          // 0 = motor por defecto, 1..n = alternativos
    private String engineUsed = null;
    private String voiceUsed = "-";
    private String pendingSpeak = null;

    /** Inicializa el motor una sola vez (async). Re-lamar es inocuo. */
    public synchronized void ensureStarted(Context c, Prefs p) {
        if (appCtx == null) appCtx = c.getApplicationContext();
        if (prefs == null) prefs = p;
        if (tts != null || exhausted) return;
        createEngine(null);
    }

    /** Reaplica voz/idioma/tono con las preferencias actuales (al cambiar de género). */
    public synchronized void reconfigure(Context c, Prefs p) {
        ensureStarted(c, p);
        if (ready && tts != null) configure();
    }

    /** Habla (o encola si el motor todavía está inicializando). */
    public synchronized void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (!ready || tts == null) {
            pendingSpeak = text;
            if (appCtx != null && prefs != null) ensureStarted(appCtx, prefs);
            return;
        }
        try {
            Bundle params = new Bundle();
            try {
                AudioManager am = (AudioManager) appCtx.getSystemService(Context.AUDIO_SERVICE);
                int stream = AudioManager.STREAM_MUSIC;
                if (am != null
                        && am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0
                        && am.getStreamVolume(AudioManager.STREAM_SYSTEM) > 0) {
                    stream = AudioManager.STREAM_SYSTEM; // box con música en silencio
                }
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, stream);
            } catch (Throwable ignored) {}
            tts.speak(text.trim(), TextToSpeech.QUEUE_FLUSH, params, "conitos");
        } catch (Throwable ignored) {}
    }

    /** Estado legible para mostrar en Ajustes. */
    public synchronized String status() {
        if (!ready || tts == null) {
            return "Motor de voz: no disponible. Instalá \"Síntesis de voz de Google\" desde Play Store"
                    + " y en Ajustes de Android → Salida de texto a voz elegilo como motor.";
        }
        String g = prefs != null ? prefs.ttsVoice() : "auto";
        String gg = "female".equals(g) ? "mujer" : "male".equals(g) ? "hombre" : "predeterminada";
        return "Motor: " + engineUsed + " · Voz: " + voiceUsed + " (" + gg + ")";
    }

    public synchronized boolean isReady() { return ready; }

    // ------------------------------------------------------------------ interno

    private synchronized void createEngine(String pkg) {
        releaseEngine();
        try {
            tts = pkg == null
                    ? new TextToSpeech(appCtx, initListener)
                    : new TextToSpeech(appCtx, initListener, pkg);
        } catch (Throwable t) {
            tts = null;
            tryNextEngine();
        }
    }

    private synchronized void releaseEngine() {
        if (tts != null) {
            try { tts.stop(); } catch (Throwable ignored) {}
            try { tts.shutdown(); } catch (Throwable ignored) {}
            tts = null;
        }
        ready = false;
    }

    private final TextToSpeech.OnInitListener initListener = new TextToSpeech.OnInitListener() {
        @Override public void onInit(int status) {
            synchronized (Tts.this) {
                if (status != TextToSpeech.SUCCESS || tts == null) {
                    tryNextEngine();
                    return;
                }
                engineUsed = (engineIdx == 0 && tts.getDefaultEngine() != null
                        && !tts.getDefaultEngine().isEmpty())
                        ? prettyEngine(tts.getDefaultEngine())
                        : (engineIdx == 0 ? "motor del sistema" : prettyEngine(FALLBACK_ENGINES[engineIdx - 1]));
                configure();
                ready = true;
                if (pendingSpeak != null) {
                    String s = pendingSpeak;
                    pendingSpeak = null;
                    speak(s);
                }
            }
        }
    };

    private synchronized void tryNextEngine() {
        releaseEngine();
        engineIdx++;
        if (engineIdx <= FALLBACK_ENGINES.length) {
            createEngine(FALLBACK_ENGINES[engineIdx - 1]);
        } else {
            exhausted = true;
            engineUsed = null;
        }
    }

    /** Configura idioma, voz por género y tono. */
    private synchronized void configure() {
        if (tts == null) return;

        // 1) Idioma español con cadena de reemplazo
        Locale chosen = null;
        Locale[] chain = {
                new Locale("es", "AR"), new Locale("es", "MX"), new Locale("es", "US"),
                new Locale("es", "ES"), new Locale("es", "419"), new Locale("es"),
                Locale.getDefault()
        };
        for (Locale l : chain) {
            try {
                int r = tts.isLanguageAvailable(l);
                if (r >= TextToSpeech.LANG_AVAILABLE) { chosen = l; break; }
            } catch (Throwable ignored) {}
        }

        // 2) Voz por género según el ajuste elegido
        String want = prefs != null ? prefs.ttsVoice() : "auto";
        voiceUsed = "-";
        boolean genderApplied = false;
        if (!"auto".equals(want)) {
            Voice v = pickVoice(tts.getVoices(), want, chosen);
            if (v != null) {
                try {
                    if (tts.setVoice(v) >= TextToSpeech.LANG_AVAILABLE) {
                        voiceUsed = v.getName();
                        genderApplied = true;
                    }
                } catch (Throwable ignored) {}
            }
        }
        if (!genderApplied && chosen != null) {
            try {
                int r = tts.setLanguage(chosen);
                if (r >= TextToSpeech.LANG_AVAILABLE) voiceUsed = chosen.toLanguageTag();
            } catch (Throwable ignored) {}
        }

        // 3) Tono: si no hubo voz real del motor con ese género, lo hacemos audible con el tono
        float pitch = 1.0f;
        if ("female".equals(want)) pitch = genderApplied ? 1.08f : 1.22f;
        else if ("male".equals(want)) pitch = genderApplied ? 0.92f : 0.78f;
        try { tts.setPitch(pitch); } catch (Throwable ignored) {}
        try { tts.setSpeechRate(1.0f); } catch (Throwable ignored) {}
    }

    /** Elige una voz del motor para el género pedido, priorizando es-AR y voces locales. */
    private static Voice pickVoice(Set<Voice> voices, String gender, Locale prefer) {
        if (voices == null || voices.isEmpty()) return null;
        List<Voice> es = new ArrayList<>();
        for (Voice v : voices) {
            try {
                Locale vl = v.getLocale();
                if (vl == null) continue;
                String lang = vl.getLanguage();               // "es"
                if ("es".equalsIgnoreCase(lang) || "spa".equalsIgnoreCase(vl.getISO3Language())) {
                    es.add(v);
                }
            } catch (Throwable ignored) {}
        }
        if (es.isEmpty()) return null;

        final String prefCountry = prefer != null ? prefer.getCountry() : "";
        Collections.sort(es, new Comparator<Voice>() {
            @Override public int compare(Voice a, Voice b) { return score(b, prefCountry) - score(a, prefCountry); }
        });

        // a) nombre explícito del género
        for (Voice v : es) {
            if ("female".equals(gender) && FEMALE_NAME.matcher(v.getName()).find()) return v;
            if ("male".equals(gender) && MALE_NAME.matcher(v.getName()).find()) return v;
        }
        // b) algunos motores codifican género como -f- / -m- en el nombre
        for (Voice v : es) {
            String n = v.getName().toLowerCase(Locale.ROOT);
            boolean female = n.contains("-f-") || n.endsWith("-f") || n.contains("x-f");
            boolean male = n.contains("-m-") || n.endsWith("-m") || n.contains("x-m");
            if ("female".equals(gender) && female) return v;
            if ("male".equals(gender) && male) return v;
        }
        return null;
    }

    private static int score(Voice v, String prefCountry) {
        int s = 0;
        try {
            Locale l = v.getLocale();
            if (l != null) {
                String c = l.getCountry();
                if (c != null && !c.isEmpty() && c.equalsIgnoreCase(prefCountry)) s += 100;
                if ("AR".equals(c)) s += 40;
                else if ("MX".equals(c)) s += 30;
                else if ("US".equals(c)) s += 20;
                else if ("419".equals(c)) s += 25;
                if (v.getQuality() >= Voice.QUALITY_NORMAL) s += 5;
                if (!v.isNetworkConnectionRequired()) s += 10;
            }
        } catch (Throwable ignored) {}
        return s;
    }

    private static String prettyEngine(String pkg) {
        if (pkg == null) return "motor del sistema";
        if (pkg.contains("google")) return "Google TTS";
        if (pkg.contains("pico")) return "Pico TTS";
        if (pkg.contains("espeak")) return "eSpeak";
        if (pkg.contains("iflytek")) return "iFlytek TTS";
        if (pkg.contains("huawei")) return "Huawei TTS";
        return pkg;
    }
}
