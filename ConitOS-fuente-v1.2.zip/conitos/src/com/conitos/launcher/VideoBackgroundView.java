package com.conitos.launcher;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;

/**
 * Fondo de pantalla en video (MP4 y afines): se reproduce en bucle, siempre
 * mudo (es el fondo del launcher) y con recorte tipo "centerCrop" para cubrir
 * toda la pantalla. Usa TextureView para que quede debajo del resto de la UI
 * y soporte transparencias del vidrio.
 */
public class VideoBackgroundView extends TextureView implements TextureView.SurfaceTextureListener {

    private final String path;
    private MediaPlayer player;
    private int videoW = 1, videoH = 1;
    private boolean errorShown = false;

    public VideoBackgroundView(Context c, String filePath) {
        super(c);
        path = filePath;
        setSurfaceTextureListener(this);
    }

    private void start(Surface surface) {
        releasePlayer();
        try {
            player = new MediaPlayer();
            player.setDataSource(path);
            player.setSurface(surface);
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setVolume(0f, 0f);          // el fondo siempre silencioso
            player.setLooping(true);
            player.setOnPreparedListener(mp -> {
                videoW = Math.max(1, mp.getVideoWidth());
                videoH = Math.max(1, mp.getVideoHeight());
                applyCrop();
                mp.start();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                releasePlayer();
                if (!errorShown) {
                    errorShown = true;
                    UiUtil.toast(getContext(), "El video de fondo no se pudo reproducir (usá MP4)");
                }
                return true;
            });
            player.prepareAsync();
        } catch (Throwable t) {
            releasePlayer();
        }
    }

    /** Escala el video desde el centro hasta cubrir la pantalla (centerCrop). */
    private void applyCrop() {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float s = Math.max((float) w / videoW, (float) h / videoH);
        Matrix m = new Matrix();
        m.setScale(s, s, w / 2f, h / 2f);
        setTransform(m);
    }

    public void release() {
        releasePlayer();
    }

    private void releasePlayer() {
        if (player != null) {
            try { player.stop(); } catch (Throwable ignored) {}
            try { player.release(); } catch (Throwable ignored) {}
            player = null;
        }
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        start(new Surface(st));
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
        applyCrop();
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        releasePlayer();
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {
        // cada fotograma: nada extra
    }
}
