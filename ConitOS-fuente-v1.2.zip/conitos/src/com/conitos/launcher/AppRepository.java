package com.conitos.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Catálogo de apps instaladas + búsqueda difusa de nombres. */
public class AppRepository {

    public static class AppInfo {
        public String label;
        public String pkg;
        public String cls;
        public Drawable icon;
    }

    private static final String SELF = "com.conitos.launcher";

    public static List<AppInfo> list(Context c) {
        PackageManager pm = c.getPackageManager();
        LinkedHashMap<String, AppInfo> map = new LinkedHashMap<>();
        addAll(map, pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0), pm);
        addAll(map, pm.queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER"), 0), pm);
        List<AppInfo> out = new ArrayList<>(map.values());
        Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
        return out;
    }

    private static void addAll(LinkedHashMap<String, AppInfo> map, List<ResolveInfo> list, PackageManager pm) {
        if (list == null) return;
        for (ResolveInfo ri : list) {
            if (ri == null || ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (SELF.equals(pkg)) continue;
            String key = pkg + "/" + ri.activityInfo.name;
            if (map.containsKey(key)) continue;
            AppInfo ai = new AppInfo();
            ai.label = String.valueOf(ri.loadLabel(pm));
            ai.pkg = pkg;
            ai.cls = ri.activityInfo.name;
            try { ai.icon = ri.loadIcon(pm); } catch (Throwable t) { ai.icon = null; }
            map.put(key, ai);
        }
    }

    /** Búsqueda difusa: devuelve la mejor app o null. */
    public static AppInfo fuzzy(List<AppInfo> apps, String term) {
        String q = UiUtil.norm(term);
        if (q.length() < 2 || apps == null) return null;
        AppInfo best = null;
        int bestScore = -1;
        for (AppInfo a : apps) {
            String l = UiUtil.norm(a.label);
            String p = UiUtil.norm(a.pkg);
            int s;
            if (l.equals(q)) s = 100;
            else if (l.startsWith(q)) s = 92;
            else if (l.contains(q)) s = 82;
            else if (p.contains(q)) s = 72;
            else {
                String[] qt = q.split("\\s+");
                String[] lt = l.split("\\s+");
                int hits = 0;
                for (String x : qt) {
                    boolean hit = false;
                    for (String y : lt) if (y.contains(x) || x.contains(y)) { hit = true; break; }
                    if (hit) hits++;
                }
                if (hits == qt.length) s = 62;
                else if (hits > 0) s = 45 + hits * 5;
                else s = -1;
            }
            if (s > bestScore) { bestScore = s; best = a; }
        }
        return bestScore >= 62 ? best : null;
    }

    public static AppInfo byPackage(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            i.setPackage(pkg);
            List<ResolveInfo> rs = pm.queryIntentActivities(i, 0);
            if (rs != null && !rs.isEmpty()) {
                ResolveInfo ri = rs.get(0);
                AppInfo a = new AppInfo();
                a.label = String.valueOf(ri.loadLabel(pm));
                a.pkg = pkg;
                a.cls = ri.activityInfo.name;
                try { a.icon = ri.loadIcon(pm); } catch (Throwable t) { a.icon = null; }
                return a;
            }
            Intent t = new Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER");
            t.setPackage(pkg);
            List<ResolveInfo> ts = pm.queryIntentActivities(t, 0);
            if (ts != null && !ts.isEmpty()) {
                ResolveInfo ri = ts.get(0);
                AppInfo a = new AppInfo();
                a.label = String.valueOf(ri.loadLabel(pm));
                a.pkg = pkg;
                a.cls = ri.activityInfo.name;
                try { a.icon = ri.loadIcon(pm); } catch (Throwable th) { a.icon = null; }
                return a;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public static void launch(Context c, AppInfo a) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setClassName(a.pkg, a.cls);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            c.startActivity(i);
            return;
        } catch (Throwable ignored) {}
        try {
            Intent i2 = c.getPackageManager().getLaunchIntentForPackage(a.pkg);
            if (i2 != null) {
                i2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                c.startActivity(i2);
            }
        } catch (Throwable ignored) {}
    }

    public static String slotKey(AppInfo a) {
        return a.pkg + "|" + a.cls;
    }

    public static AppInfo fromSlot(Context c, String slot) {
        if (slot == null || slot.isEmpty()) return null;
        int ix = slot.indexOf('|');
        if (ix <= 0) return null;
        AppInfo a = new AppInfo();
        a.pkg = slot.substring(0, ix);
        a.cls = slot.substring(ix + 1);
        try {
            PackageManager pm = c.getPackageManager();
            android.content.pm.ActivityInfo info = pm.getActivityInfo(new android.content.ComponentName(a.pkg, a.cls), 0);
            a.label = String.valueOf(info.loadLabel(pm));
            a.icon = info.loadIcon(pm);
        } catch (Throwable t) {
            try {
                a.icon = c.getPackageManager().getApplicationIcon(a.pkg);
            } catch (Throwable th) {
                a.icon = null;
            }
        }
        return a;
    }

    /** Accesos por defecto: Netflix, YouTube, Kodi, IPTV, Chrome, Play Store. */
    public static List<String> resolveDefaults(Context c) {
        Map<String, String> dict = new HashMap<>();
        dict.put("netflix", "com.netflix.mediaclient");
        dict.put("youtube", "com.google.android.youtube");
        dict.put("kodi", "org.xbmc.kodi");
        dict.put("chrome", "com.android.chrome");
        dict.put("play store", "com.android.vending");
        dict.put("iptv", null);

        List<AppInfo> apps = list(c);
        List<String> out = new ArrayList<>();
        for (String t : new String[]{"Netflix", "YouTube", "Kodi", "IPTV", "Chrome", "Play Store"}) {
            AppInfo found = null;
            String want = dict.get(UiUtil.norm(t));
            if (want != null) {
                for (AppInfo a : apps) if (a.pkg.equals(want)) { found = a; break; }
            }
            if (found == null) found = fuzzy(apps, t);
            out.add(found != null ? slotKey(found) : "");
        }
        return out;
    }
}
