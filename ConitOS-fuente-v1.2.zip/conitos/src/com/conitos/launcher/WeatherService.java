package com.conitos.launcher;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Clima via Open-Meteo (gratis, sin API key) + geocodificación. */
public class WeatherService {

    public interface Callback { void onResult(JSONObject current); }
    public interface LocCallback { void onResult(String city, String lat, String lon, String error); }

    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static void fetchAsync(Prefs prefs, boolean force, Callback cb) {
        String cached = prefs.weather();
        long ts = prefs.weatherTs();
        if (!force && cached != null && System.currentTimeMillis() - ts < 30 * 60 * 1000L) {
            try { cb.onResult(new JSONObject(cached).getJSONObject("current")); return; } catch (Exception ignored) {}
        }
        EX.execute(() -> {
            JSONObject out = null;
            try {
                String url = "https://api.open-meteo.com/v1/forecast?latitude=" + URLEncoder.encode(prefs.lat(), "UTF-8")
                        + "&longitude=" + URLEncoder.encode(prefs.lon(), "UTF-8")
                        + "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto";
                JSONObject root = new JSONObject(httpGet(url));
                out = root.getJSONObject("current");
                prefs.weather(root.toString());
            } catch (Throwable ignored) {}
            final JSONObject f = out;
            MAIN.post(() -> { try { cb.onResult(f); } catch (Throwable ignored) {} });
        });
    }

    public static void geocodeAsync(String city, LocCallback cb) {
        EX.execute(() -> {
            try {
                String url = "https://geocoding-api.open-meteo.com/v1/search?name="
                        + URLEncoder.encode(city, "UTF-8") + "&count=1&language=es&format=json";
                JSONObject root = new JSONObject(httpGet(url));
                JSONArray res = root.optJSONArray("results");
                if (res != null && res.length() > 0) {
                    JSONObject r = res.getJSONObject(0);
                    String name = r.optString("name") + (r.has("admin1") ? ", " + r.optString("admin1") : "");
                    MAIN.post(() -> cb.onResult(name, String.valueOf(r.optDouble("latitude")),
                            String.valueOf(r.optDouble("longitude")), null));
                    return;
                }
            } catch (Throwable ignored) {}
            MAIN.post(() -> cb.onResult(null, null, null, "No encontré esa ciudad. Probá con otra."));
        });
    }

    public static void autoLocateAsync(LocCallback cb) {
        EX.execute(() -> {
            try {
                JSONObject r = new JSONObject(httpGet("https://ipapi.co/json/"));
                double lat = r.optDouble("latitude", 999);
                double lon = r.optDouble("longitude", 999);
                if (lat != 999 && lon != 999) {
                    String name = r.optString("city", "Mi ubicación");
                    MAIN.post(() -> cb.onResult(name, String.valueOf(lat), String.valueOf(lon), null));
                    return;
                }
            } catch (Throwable ignored) {}
            MAIN.post(() -> cb.onResult(null, null, null, "No se pudo detectar la ubicación (sin Internet o red sin datos)."));
        });
    }

    private static String httpGet(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(8000);
        con.setReadTimeout(8000);
        con.setRequestProperty("User-Agent", "ConitOS/1.0");
        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        con.disconnect();
        return sb.toString();
    }

    public static int iconFor(int code, boolean night) {
        if (code == 0) return night ? R.drawable.ic_moon : R.drawable.ic_sun;
        if (code == 1 || code == 2 || code == 3) return R.drawable.ic_partly;
        if (code == 45 || code == 48) return R.drawable.ic_fog;
        if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return R.drawable.ic_rain;
        if ((code >= 71 && code <= 77) || code == 85 || code == 86) return R.drawable.ic_snow;
        if (code >= 95) return R.drawable.ic_storm;
        return R.drawable.ic_cloud;
    }

    public static String textFor(int code) {
        if (code == 0) return "despejado";
        if (code == 1) return "mayormente despejado";
        if (code == 2) return "parcialmente nublado";
        if (code == 3) return "nublado";
        if (code == 45 || code == 48) return "con niebla";
        if (code >= 51 && code <= 57) return "con llovizna";
        if (code >= 61 && code <= 67) return "con lluvia";
        if (code >= 71 && code <= 77) return "con nieve";
        if (code >= 80 && code <= 82) return "con chaparrones";
        if (code == 85 || code == 86) return "con nevadas";
        if (code >= 95) return "con tormentas";
        return "variable";
    }
}
