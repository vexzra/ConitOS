package com.conitos.launcher;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.Locale;

/** Utilidades de UI: vidrio (glassmorphism), acento, normalización de texto. */
public class UiUtil {

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** minúsculas, sin tildes, espacios simples: para reconocer comandos. */
    public static String norm(String s) {
        if (s == null) return "";
        String t = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        t = t.replaceAll("\\p{M}+", "");
        return t.replaceAll("\\s+", " ").trim();
    }

    /** Color de acento: auto (Material You desde el fondo de pantalla) o hex. */
    public static int accentColor(Context c, Prefs p) {
        String a = p.accent();
        if ("auto".equalsIgnoreCase(a)) {
            try {
                if (Build.VERSION.SDK_INT >= 27) {
                    android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(c);
                    android.app.WallpaperColors wc = wm.getWallpaperColors(android.app.WallpaperManager.FLAG_SYSTEM);
                    if (wc != null && wc.getPrimaryColor() != null) {
                        int col = wc.getPrimaryColor().toArgb();
                        int sum = Color.red(col) + Color.green(col) + Color.blue(col);
                        if (sum > 90 && sum < 690) return 0xFF000000 | col;
                    }
                }
            } catch (Throwable ignored) {}
            return 0xFF8AB4F8;
        }
        try {
            int v = Color.parseColor(a);
            if ((v >>> 24) == 0) v |= 0xFF000000;
            return v;
        } catch (Throwable e) {
            return 0xFF8AB4F8;
        }
    }

    /** RGB del tinte del vidrio. */
    public static int tintRgb(Prefs p) {
        String t = p.tint();
        if ("auto".equalsIgnoreCase(t)) return 0xFFFFFF;
        try { return 0xFFFFFF & Color.parseColor(t); } catch (Throwable e) { return 0xFFFFFF; }
    }

    /** ARGB del panel de vidrio según transparencia configurada. */
    public static int glassArgb(Context c, Prefs p, boolean night) {
        int rgb = tintRgb(p);
        int alpha = Math.round(p.glassAlpha() * 255f / 100f);
        return (alpha << 24) | rgb;
    }

    public static GradientDrawable glass(Context c, int argb, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(argb);
        g.setCornerRadius(dp(c, radiusDp));
        int stroke = Color.alpha(argb) > 60 ? 0x40FFFFFF : 0x2EFFFFFF;
        g.setStroke(dp(c, 1f), stroke);
        return g;
    }

    public static GradientDrawable glassOval(Context c, int argb) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(argb);
        g.setStroke(dp(c, 1f), 0x2EFFFFFF);
        return g;
    }

    public static GradientDrawable glassOvalFocused(Context c, int argb, int accent) {
        GradientDrawable g = glassOval(c, argb);
        g.setColor(brighten(argb));
        g.setStroke(dp(c, 1.6f), accent);
        return g;
    }

    public static GradientDrawable glassFocused(Context c, int argb, int accent, float radiusDp) {
        GradientDrawable g = glass(c, brighten(argb), radiusDp);
        g.setStroke(dp(c, 1.6f), accent);
        return g;
    }

    private static int brighten(int argb) {
        return Color.argb(
                Math.min(255, Color.alpha(argb) + 44),
                Math.min(255, Color.red(argb) + 26),
                Math.min(255, Color.green(argb) + 26),
                Math.min(255, Color.blue(argb) + 26));
    }

    public static StateListDrawable focusSelector(GradientDrawable normal, GradientDrawable focused) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, focused);
        s.addState(new int[]{android.R.attr.state_pressed}, focused);
        s.addState(new int[]{}, normal);
        return s;
    }

    public static void toast(Context c, String m) {
        Toast.makeText(c, m, Toast.LENGTH_SHORT).show();
    }
}
