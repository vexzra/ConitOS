package com.conitos.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Al encender el equipo: precarga el clima para que el Home lo muestre al instante. */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            try {
                Prefs p = new Prefs(context);
                WeatherService.fetchAsync(p, true, data -> { });
            } catch (Throwable ignored) {}
        }
    }
}
