package com.conitos.launcher;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Shader.TileMode;
import android.os.Build;
import android.widget.ImageView;

/** Desenfoque: RenderEffect GPU en Android 12+, box blur por CPU en versiones previas. */
public class BlurUtil {

    public static boolean gpu() {
        return Build.VERSION.SDK_INT >= 31;
    }

    public static void apply(ImageView iv, Bitmap bmp, int radius) {
        if (bmp == null) return;
        if (Build.VERSION.SDK_INT >= 31) {
            iv.setImageBitmap(bmp);
            try {
                if (radius <= 0) {
                    iv.setRenderEffect(null);
                } else {
                    iv.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(radius, radius, TileMode.CLAMP));
                }
            } catch (Throwable ignored) {}
        } else {
            Bitmap b = bmp;
            if (radius > 0) {
                b = scaleDown(bmp, 900);
                b = boxBlur(b, Math.max(1, Math.min(20, radius / 2)));
            }
            iv.setImageBitmap(b);
        }
    }

    private static Bitmap scaleDown(Bitmap src, int maxW) {
        if (src.getWidth() <= maxW) return src;
        float f = (float) maxW / src.getWidth();
        return Bitmap.createScaledBitmap(src, maxW, Math.round(src.getHeight() * f), true);
    }

    /** Box blur de dos pasadas (horizontal + vertical), aproximacion gaussiana. */
    public static Bitmap boxBlur(Bitmap src, int radius) {
        if (src == null || radius < 1) return src;
        int w = src.getWidth();
        int h = src.getHeight();
        int[] pix = new int[w * h];
        src.getPixels(pix, 0, w, 0, 0, w, h);
        int wm = w - 1, hm = h - 1;
        int div = radius + radius + 1;

        int[] r = new int[w * h];
        int[] g = new int[w * h];
        int[] b = new int[w * h];

        // Pasada horizontal
        for (int y = 0; y < h; y++) {
            int row = y * w;
            int rs = 0, gs = 0, bs = 0;
            for (int i = -radius; i <= radius; i++) {
                int p = pix[row + Math.min(wm, Math.max(0, i))];
                rs += (p & 0xff0000) >> 16;
                gs += (p & 0x00ff00) >> 8;
                bs += p & 0x0000ff;
            }
            for (int x = 0; x < w; x++) {
                r[row + x] = rs / div;
                g[row + x] = gs / div;
                b[row + x] = bs / div;
                int pa = pix[row + Math.min(wm, x + radius + 1)];
                int pb = pix[row + Math.max(0, x - radius)];
                rs += ((pa & 0xff0000) >> 16) - ((pb & 0xff0000) >> 16);
                gs += ((pa & 0x00ff00) >> 8) - ((pb & 0x00ff00) >> 8);
                bs += (pa & 0x0000ff) - (pb & 0x0000ff);
            }
        }

        // Pasada vertical
        for (int x = 0; x < w; x++) {
            int rs = 0, gs = 0, bs = 0;
            for (int i = -radius; i <= radius; i++) {
                int idx = Math.min(hm, Math.max(0, i)) * w + x;
                rs += r[idx];
                gs += g[idx];
                bs += b[idx];
            }
            for (int y = 0; y < h; y++) {
                pix[y * w + x] = 0xff000000 | ((rs / div) << 16) | ((gs / div) << 8) | (bs / div);
                int pa = Math.min(hm, y + radius + 1) * w + x;
                int pb = Math.max(0, y - radius) * w + x;
                rs += r[pa] - r[pb];
                gs += g[pa] - g[pb];
                bs += b[pa] - b[pb];
            }
        }

        Bitmap out = Bitmap.createBitmap(w, h, Config.ARGB_8888);
        out.setPixels(pix, 0, w, 0, 0, w, h);
        return out;
    }
}
