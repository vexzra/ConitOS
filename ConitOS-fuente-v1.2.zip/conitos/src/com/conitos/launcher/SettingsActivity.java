package com.conitos.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Personalización completa: fondo, vidrio, reloj, clima, accesos, acento, voz. */
public class SettingsActivity extends Activity {

    private Prefs prefs;
    private LinearLayout tintRow, accentRow, slotsBox;
    private TextView lblBlur, lblGlass, lblClock, lblIcons, weatherPreview;
    private SeekBar seekBlur, seekGlass, seekClock, seekIcons;
    private Switch switchSeconds, switchTts, switchAnim;
    private RadioGroup radioNight, radioVoice;
    private TextView ttsStatus;
    private EditText cityEdit;

    private static final int REQ_BG = 7;
    private static final int REQ_BG_VIDEO = 8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        setContentView(R.layout.activity_settings);

        tintRow = findViewById(R.id.tintRow);
        accentRow = findViewById(R.id.accentRow);
        slotsBox = findViewById(R.id.slotsBox);
        lblBlur = findViewById(R.id.lblBlur);
        lblGlass = findViewById(R.id.lblGlass);
        lblClock = findViewById(R.id.lblClock);
        lblIcons = findViewById(R.id.lblIcons);
        weatherPreview = findViewById(R.id.weatherPreview);
        seekBlur = findViewById(R.id.seekBlur);
        seekGlass = findViewById(R.id.seekGlass);
        seekClock = findViewById(R.id.seekClock);
        seekIcons = findViewById(R.id.seekIcons);
        switchSeconds = findViewById(R.id.switchSeconds);
        switchTts = findViewById(R.id.switchTts);
        switchAnim = findViewById(R.id.switchAnim);
        radioNight = findViewById(R.id.radioNight);
        radioVoice = findViewById(R.id.radioVoice);
        ttsStatus = findViewById(R.id.ttsStatus);
        cityEdit = findViewById(R.id.cityEdit);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnPickBg).setOnClickListener(v -> pickBackground());
        findViewById(R.id.btnPickVideo).setOnClickListener(v -> pickBackgroundVideo());
        findViewById(R.id.btnRemoveBg).setOnClickListener(v -> removeBackground());
        findViewById(R.id.btnCitySave).setOnClickListener(v -> saveCity());
        findViewById(R.id.btnCityAuto).setOnClickListener(v -> autoCity());
        findViewById(R.id.btnWeatherNow).setOnClickListener(v -> {
            UiUtil.toast(this, "Actualizando clima…");
            WeatherService.fetchAsync(prefs, true, cur -> { updateWeatherPreview(); UiUtil.toast(this, "Clima actualizado"); });
        });
        findViewById(R.id.btnAddSlot).setOnClickListener(v -> addSlot());

        // Sliders
        seekBlur.setMax(25);
        seekBlur.setProgress(prefs.blur());
        lblBlur.setText("Desenfoque del fondo: " + prefs.blur());
        seekBlur.setOnSeekBarChangeListener(simple((sb, v) -> {
            prefs.blur(v);
            lblBlur.setText("Desenfoque del fondo: " + v);
        }));

        seekGlass.setMax(60);
        seekGlass.setProgress(prefs.glassAlpha());
        lblGlass.setText("Transparencia del vidrio: " + prefs.glassAlpha() + "%");
        seekGlass.setOnSeekBarChangeListener(simple((sb, v) -> {
            prefs.glassAlpha(v);
            lblGlass.setText("Transparencia del vidrio: " + v + "%");
        }));

        seekClock.setMax(84);
        seekClock.setProgress(prefs.clockSize() - 56);
        lblClock.setText("Tamaño del reloj: " + prefs.clockSize() + "sp");
        seekClock.setOnSeekBarChangeListener(simple((sb, v) -> {
            prefs.clockSize(v + 56);
            lblClock.setText("Tamaño del reloj: " + (v + 56) + "sp");
        }));

        seekIcons.setMax(40);
        seekIcons.setProgress(prefs.iconSize() - 44);
        lblIcons.setText("Tamaño de íconos de accesos: " + prefs.iconSize() + "dp");
        seekIcons.setOnSeekBarChangeListener(simple((sb, v) -> {
            prefs.iconSize(v + 44);
            lblIcons.setText("Tamaño de íconos de accesos: " + (v + 44) + "dp");
        }));

        // Switches
        switchSeconds.setChecked(prefs.seconds());
        switchSeconds.setOnCheckedChangeListener((b, v) -> prefs.seconds(v));
        switchTts.setChecked(prefs.tts());
        switchTts.setOnCheckedChangeListener((b, v) -> prefs.tts(v));

        // Voz del asistente: mujer / hombre / automática (se escucha al cambiar)
        Tts.get().ensureStarted(getApplicationContext(), prefs);
        String voice = prefs.ttsVoice();
        if ("female".equals(voice)) radioVoice.check(R.id.rVoiceFemale);
        else if ("male".equals(voice)) radioVoice.check(R.id.rVoiceMale);
        else radioVoice.check(R.id.rVoiceAuto);
        radioVoice.setOnCheckedChangeListener((g, id) -> {
            String v = id == R.id.rVoiceFemale ? "female" : id == R.id.rVoiceMale ? "male" : "auto";
            prefs.ttsVoice(v);
            Tts.get().reconfigure(getApplicationContext(), prefs);
            if (prefs.tts()) Tts.get().speak(id == R.id.rVoiceFemale
                    ? "Hola, soy ConitOS y esta es mi voz de mujer."
                    : id == R.id.rVoiceMale
                    ? "Hola, soy ConitOS y esta es mi voz de hombre."
                    : "Voz del motor configurada.");
            refreshTtsStatus();
        });
        findViewById(R.id.btnVoiceTest).setOnClickListener(v -> {
            if (!prefs.tts()) { UiUtil.toast(this, "Activá \"Responder con voz\" primero"); return; }
            Tts.get().reconfigure(getApplicationContext(), prefs);
            Tts.get().speak("Hola, soy ConitOS, tu asistente de voz. ¿En qué puedo ayudarte?");
            refreshTtsStatus();
        });
        switchAnim.setChecked(prefs.anim());
        switchAnim.setOnCheckedChangeListener((b, v) -> prefs.anim(v));

        // Modo claro/oscuro
        String night = prefs.nightMode();
        if ("dark".equals(night)) radioNight.check(R.id.rNightDark);
        else if ("light".equals(night)) radioNight.check(R.id.rNightLight);
        else radioNight.check(R.id.rNightAuto);
        radioNight.setOnCheckedChangeListener((g, id) -> {
            if (id == R.id.rNightDark) prefs.nightMode("dark");
            else if (id == R.id.rNightLight) prefs.nightMode("light");
            else prefs.nightMode("auto");
        });

        cityEdit.setText(prefs.city());

        buildTintRow();
        buildAccentRow();
        rebuildSlots();
        updateWeatherPreview();
        refreshTtsStatus();
        // El motor TTS se inicializa en segundo plano: refrescamos el estado un poco después
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::refreshTtsStatus, 1800);
        ((TextView) findViewById(R.id.aboutText)).setText(
                "ConitOS Launcher 1.2 · Launcher HOME para TV Box con vidrio, voz y clima.\n\n"
                        + "· Para que arranque al encender: presioná el botón HOME del control y elegí \"ConitOS · Siempre\".\n"
                        + "· Fondo animado: podés usar una imagen, un GIF o un video MP4 (en bucle y mudo).\n"
                        + "· El botón de micrófono del control (o la búsqueda) abre la escucha de voz.\n"
                        + "· La voz de respuesta puede ser de mujer o de hombre. Si no habla nada, instalá \"Síntesis de voz de Google\" desde Play Store y ponelo como motor de texto a voz.\n"
                        + "· Clima vía Open-Meteo (gratis, sin clave).\n"
                        + "· Reiniciar y apagar por voz requieren instalar la app como aplicación de sistema.\n"
                        + "· Desenfoque GPU en Android 12+; en versiones anteriores se usa desenfoque por software.");
    }

    private interface OnChange { void run(SeekBar sb, int v); }

    private void refreshTtsStatus() {
        ttsStatus.setText(Tts.get().status());
    }

    private SeekBar.OnSeekBarChangeListener simple(OnChange o) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean fromUser) { if (fromUser) o.run(sb, v); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        };
    }

    // ------------------------------------------------------------- colores

    private void buildTintRow() {
        String[][] presets = {
                {"Auto", "auto"},
                {"Blanco", "#FFFFFF"},
                {"Grafito", "#20242C"},
                {"Azul", "#2A4A7A"},
                {"Violeta", "#4A2A6A"},
                {"Menta", "#2A5A46"},
        };
        buildColorRow(tintRow, presets, prefs.tint(), sel -> { prefs.tint(sel); buildTintRow(); });
    }

    private void buildAccentRow() {
        String[][] presets = {
                {"Auto (Material You)", "auto"},
                {"Celeste", "#8AB4F8"},
                {"Menta", "#7DD3A0"},
                {"Violeta", "#C58AF9"},
                {"Naranja", "#FFB86B"},
                {"Rosa", "#FF8FA3"},
                {"Amarillo", "#FFD666"},
        };
        buildColorRow(accentRow, presets, prefs.accent(), sel -> { prefs.accent(sel); buildAccentRow(); });
    }

    private interface Pick { void picked(String value); }

    private void buildColorRow(LinearLayout row, String[][] presets, String current, Pick pick) {
        row.removeAllViews();
        for (String[] p : presets) {
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            try { g.setColor(android.graphics.Color.parseColor(p[1])); } catch (Throwable t) { g.setColor(0xFF5F6B7A); }
            g.setStroke(UiUtil.dp(this, "auto".equals(p[1]) ? 2f : 1f),
                    p[1].equals(current) ? 0xFF8AB4F8 : 0x55FFFFFF);
            int s = UiUtil.dp(this, 34f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
            lp.setMargins(UiUtil.dp(this, 6f), UiUtil.dp(this, 2f), UiUtil.dp(this, 6f), UiUtil.dp(this, 2f));
            sw.setBackground(g);
            sw.setOnClickListener(v -> pick.picked(p[1]));
            sw.setOnLongClickListener(v -> { UiUtil.toast(this, p[0]); return true; });
            row.addView(sw, lp);
        }
    }

    // ------------------------------------------------------------- accesos

    private void rebuildSlots() {
        slotsBox.removeAllViews();
        List<String> slots = prefs.slots();
        if (slots == null) slots = new ArrayList<>();
        for (int i = 0; i < slots.size(); i++) {
            final int idx = i;
            AppRepository.AppInfo a = AppRepository.fromSlot(this, slots.get(i));

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(0, UiUtil.dp(this, 6f), 0, UiUtil.dp(this, 6f));

            ImageView ic = new ImageView(this);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                    UiUtil.dp(this, 34f), UiUtil.dp(this, 34f));
            if (a != null && a.icon != null) ic.setImageDrawable(a.icon);
            else ic.setImageResource(R.drawable.ic_add);
            ic.setColorFilter(a != null ? 0 : 0x88FFFFFF);
            row.addView(ic, ilp);

            TextView t = new TextView(this);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tlp.leftMargin = UiUtil.dp(this, 12f);
            t.setText(a != null ? a.label : "Vacío (tocá para elegir)");
            t.setTextColor(a != null ? 0xFFF2F5FA : 0x88FFFFFF);
            t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14);
            row.addView(t, tlp);

            Button change = new Button(this);
            change.setText("Cambiar");
            change.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12);
            change.setOnClickListener(v -> openPickerDialog(idx, this::rebuildSlots));
            row.addView(change, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            Button remove = new Button(this);
            remove.setText("Quitar");
            remove.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12);
            remove.setOnClickListener(v -> {
                List<String> s = prefs.slots();
                if (s != null && idx < s.size()) s.set(idx, "");
                prefs.slots(s);
                rebuildSlots();
            });
            row.addView(remove, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            slotsBox.addView(row);
        }
        if (slots.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("Sin accesos rápidos. Agregá uno abajo.");
            t.setTextColor(0x88FFFFFF);
            slotsBox.addView(t);
        }
    }

    private void addSlot() {
        List<String> slots = prefs.slots();
        if (slots == null) slots = new ArrayList<>();
        if (slots.size() >= 10) { UiUtil.toast(this, "Máximo 10 accesos rápidos"); return; }
        slots.add("");
        prefs.slots(slots);
        rebuildSlots();
    }

    private void openPickerDialog(int idx, Runnable after) {
        List<AppRepository.AppInfo> apps = AppRepository.list(this);
        if (apps.isEmpty()) { UiUtil.toast(this, "No hay aplicaciones instaladas"); return; }
        ListView lv = new ListView(this);
        lv.setAdapter(new android.widget.BaseAdapter() {
            @Override public int getCount() { return apps.size(); }
            @Override public Object getItem(int position) { return apps.get(position); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                LinearLayout row = new LinearLayout(SettingsActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                row.setPadding(UiUtil.dp(SettingsActivity.this, 16f), UiUtil.dp(SettingsActivity.this, 8f),
                        UiUtil.dp(SettingsActivity.this, 16f), UiUtil.dp(SettingsActivity.this, 8f));
                AppRepository.AppInfo a = apps.get(position);
                ImageView ic = new ImageView(SettingsActivity.this);
                ic.setLayoutParams(new LinearLayout.LayoutParams(
                        UiUtil.dp(SettingsActivity.this, 34f), UiUtil.dp(SettingsActivity.this, 34f)));
                if (a.icon != null) ic.setImageDrawable(a.icon);
                row.addView(ic);
                TextView t = new TextView(SettingsActivity.this);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tlp.leftMargin = UiUtil.dp(SettingsActivity.this, 14f);
                t.setText(a.label);
                t.setTextColor(0xFFF2F5FA);
                t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15);
                row.addView(t, tlp);
                return row;
            }
        });
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Elegir aplicación")
                .setView(lv)
                .setNegativeButton("Cancelar", null)
                .create();
        lv.setOnItemClickListener((p, v, pos, id) -> {
            List<String> slots = prefs.slots();
            if (slots == null) slots = new ArrayList<>();
            while (slots.size() <= idx) slots.add("");
            slots.set(idx, AppRepository.slotKey(apps.get(pos)));
            prefs.slots(slots);
            dlg.dismiss();
            after.run();
        });
        dlg.show();
    }

    // --------------------------------------------------------------- fondo

    private void pickBackground() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Elegir imagen o GIF de fondo"), REQ_BG);
        } catch (Throwable t) {
            UiUtil.toast(this, "No hay selector de archivos disponible");
        }
    }

    /** Video de fondo (MP4): se guarda tal cual y se reproduce en bucle y mudo. */
    private void pickBackgroundVideo() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("video/mp4");
            startActivityForResult(Intent.createChooser(i, "Elegir video de fondo"), REQ_BG_VIDEO);
        } catch (Throwable t) {
            UiUtil.toast(this, "No hay selector de archivos disponible");
        }
    }

    private void removeBackground() {
        try {
            for (String n : new String[]{"bg.jpg", "bg.gif", "bg.mp4"}) {
                new File(getFilesDir(), n).delete();
            }
        } catch (Throwable ignored) {}
        prefs.bgVersion(prefs.bgVersion() + 1);
        UiUtil.toast(this, "Fondo quitado");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        boolean gotImage = requestCode == REQ_BG && resultCode == RESULT_OK && data != null && data.getData() != null;
        boolean gotVideo = requestCode == REQ_BG_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null;
        if (!gotImage && !gotVideo) return;

        if (gotVideo) {
            try {
                InputStream in = getContentResolver().openInputStream(data.getData());
                UiUtil.toast(this, "Guardando video de fondo…");
                saveStreamAsync(in, "bg.mp4", 300L * 1024 * 1024, "video");
            } catch (Throwable t) {
                UiUtil.toast(this, "No pude cargar el video");
            }
            return;
        }

        try {
            InputStream in = getContentResolver().openInputStream(data.getData());
            byte[] bytes = readStream(in);
            boolean gif = bytes.length > 3 && bytes[0] == 'G' && bytes[1] == 'I' && bytes[2] == 'F';
            if (gif) {
                // GIF animado: se guarda sin recomprimir para conservar la animación
                saveBytesAsync(bytes, "bg.gif", "GIF");
                return;
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = Math.max(1, o.outWidth / 1600);
            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o2);
            if (bmp != null) {
                FileOutputStream fo = openFileOutput("bg.jpg", MODE_PRIVATE);
                bmp.compress(Bitmap.CompressFormat.JPEG, 88, fo);
                fo.close();
                clearOtherBg("bg.jpg");
                prefs.bgVersion(prefs.bgVersion() + 1);
                UiUtil.toast(this, "Fondo aplicado");
            } else {
                UiUtil.toast(this, "No pude cargar la imagen");
            }
        } catch (Throwable t) {
            UiUtil.toast(this, "No pude cargar la imagen");
        }
    }

    /** Borra los archivos de fondo que no sean el actual. */
    private void clearOtherBg(String keep) {
        String[] names = {"bg.jpg", "bg.gif", "bg.mp4"};
        for (String n : names) {
            if (!n.equals(keep)) new File(getFilesDir(), n).delete();
        }
    }

    /** Guarda un archivo de fondo en un hilo aparte y avisa al terminar. */
    private void saveBytesAsync(final byte[] bytes, final String name, final String kind) {
        new Thread(() -> {
            try {
                FileOutputStream fo = openFileOutput(name, MODE_PRIVATE);
                fo.write(bytes);
                fo.close();
                clearOtherBg(name);
                prefs.bgVersion(prefs.bgVersion() + 1);
                runOnUiThread(() -> UiUtil.toast(SettingsActivity.this, "Fondo " + kind + " aplicado"));
            } catch (Throwable t) {
                runOnUiThread(() -> UiUtil.toast(SettingsActivity.this, "No pude guardar el archivo"));
            }
        }, "conitos-bg").start();
    }

    /** Copia un archivo grande (video) al almacenamiento interno con tope de tamaño. */
    private void saveStreamAsync(final InputStream in, final String name, final long cap, final String kind) {
        new Thread(() -> {
            boolean ok = false;
            boolean tooBig = false;
            try {
                File tmp = new File(getFilesDir(), name + ".tmp");
                FileOutputStream fo = new FileOutputStream(tmp);
                byte[] buf = new byte[65536];
                long total = 0;
                int n;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > cap) { tooBig = true; break; }
                    fo.write(buf, 0, n);
                }
                fo.close();
                in.close();
                if (tooBig) {
                    tmp.delete();
                } else {
                    new File(getFilesDir(), name).delete();
                    ok = tmp.renameTo(new File(getFilesDir(), name));
                    clearOtherBg(name);
                    if (ok) prefs.bgVersion(prefs.bgVersion() + 1);
                }
            } catch (Throwable t) {
                ok = false;
                new File(getFilesDir(), name + ".tmp").delete();
            }
            final boolean fok = ok;
            final boolean fbig = tooBig;
            runOnUiThread(() -> {
                if (fok) UiUtil.toast(SettingsActivity.this, "Fondo " + kind + " aplicado");
                else if (fbig) UiUtil.toast(SettingsActivity.this, "El video es demasiado grande (máximo 300 MB)");
                else UiUtil.toast(SettingsActivity.this, "No pude guardar el archivo");
            });
        }, "conitos-bg").start();
    }

    private byte[] readStream(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return bos.toByteArray();
    }

    // ---------------------------------------------------------------- clima

    private void saveCity() {
        String city = cityEdit.getText().toString().trim();
        if (city.isEmpty()) { UiUtil.toast(this, "Escribí una ciudad"); return; }
        UiUtil.toast(this, "Buscando \"" + city + "\"…");
        WeatherService.geocodeAsync(city, (name, lat, lon, error) -> {
            if (error != null) { UiUtil.toast(this, error); return; }
            prefs.location(name, lat, lon);
            cityEdit.setText(name);
            WeatherService.fetchAsync(prefs, true, cur -> updateWeatherPreview());
            UiUtil.toast(this, "Ciudad guardada: " + name);
        });
    }

    private void autoCity() {
        UiUtil.toast(this, "Detectando ubicación…");
        WeatherService.autoLocateAsync((name, lat, lon, error) -> {
            if (error != null) { UiUtil.toast(this, error); return; }
            prefs.location(name, lat, lon);
            cityEdit.setText(name);
            WeatherService.fetchAsync(prefs, true, cur -> updateWeatherPreview());
            UiUtil.toast(this, "Ubicación detectada: " + name);
        });
    }

    private void updateWeatherPreview() {
        String s = "Sin datos de clima todavía.";
        try {
            String cached = prefs.weather();
            if (cached != null) {
                JSONObject cur = new JSONObject(cached).getJSONObject("current");
                double t = cur.optDouble("temperature_2m", Double.NaN);
                int hum = cur.optInt("relative_humidity_2m", -1);
                double wind = cur.optDouble("wind_speed_10m", Double.NaN);
                int code = cur.optInt("weather_code", -1);
                s = String.format(java.util.Locale.US, "%.0f° · %s · Humedad %d%% · Viento %.0f km/h",
                        t, WeatherService.textFor(code), hum, wind);
            }
        } catch (Throwable ignored) {}
        weatherPreview.setText(prefs.city() + ": " + s);
    }
}
