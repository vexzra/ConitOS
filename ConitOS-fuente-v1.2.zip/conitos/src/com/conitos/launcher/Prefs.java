package com.conitos.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** Preferencias (reemplaza a Room por simplicidad y cero dependencias). */
public class Prefs {

    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getSharedPreferences("conitos", Context.MODE_PRIVATE);
    }

    public int blur() { return sp.getInt("blur", 14); }
    public void blur(int v) { sp.edit().putInt("blur", v).apply(); }

    public int glassAlpha() { return sp.getInt("glass_alpha", 16); }
    public void glassAlpha(int v) { sp.edit().putInt("glass_alpha", v).apply(); }

    public String tint() { return sp.getString("tint", "auto"); }
    public void tint(String v) { sp.edit().putString("tint", v).apply(); }

    public String accent() { return sp.getString("accent", "auto"); }
    public void accent(String v) { sp.edit().putString("accent", v).apply(); }

    public int clockSize() { return sp.getInt("clock_size", 84); }
    public void clockSize(int v) { sp.edit().putInt("clock_size", v).apply(); }

    public int iconSize() { return sp.getInt("icon_size", 62); }
    public void iconSize(int v) { sp.edit().putInt("icon_size", v).apply(); }

    public boolean seconds() { return sp.getBoolean("seconds", false); }
    public void seconds(boolean v) { sp.edit().putBoolean("seconds", v).apply(); }

    /** auto | dark | light */
    public String nightMode() { return sp.getString("night", "auto"); }
    public void nightMode(String v) { sp.edit().putString("night", v).apply(); }

    public boolean anim() { return sp.getBoolean("anim", true); }
    public void anim(boolean v) { sp.edit().putBoolean("anim", v).apply(); }

    public boolean tts() { return sp.getBoolean("tts", true); }
    public void tts(boolean v) { sp.edit().putBoolean("tts", v).apply(); }

    /** Género de la voz de respuesta: auto | female | male. */
    public String ttsVoice() { return sp.getString("tts_voice", "auto"); }
    public void ttsVoice(String v) { sp.edit().putString("tts_voice", v).apply(); }

    public String city() { return sp.getString("city", "Salta Capital"); }

    public String lat() { return sp.getString("lat", "-24.7828"); }
    public String lon() { return sp.getString("lon", "-65.4123"); }

    public void location(String city, String lat, String lon) {
        sp.edit().putString("city", city).putString("lat", lat).putString("lon", lon).apply();
    }

    public int bgVersion() { return sp.getInt("bg_v", 0); }
    public void bgVersion(int v) { sp.edit().putInt("bg_v", v).apply(); }

    /** Lista de accesos rápidos: "pkg|Activity" o "" si vacío. */
    public List<String> slots() {
        String s = sp.getString("slots", null);
        if (s == null) return null;
        try {
            JSONArray a = new JSONArray(s);
            List<String> r = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) r.add(a.optString(i, ""));
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    public void slots(List<String> l) {
        if (l == null) return;
        try {
            JSONArray a = new JSONArray();
            for (String x : l) a.put(x == null ? "" : x);
            sp.edit().putString("slots", a.toString()).apply();
        } catch (Exception ignored) {}
    }

    public String weather() { return sp.getString("weather", null); }
    public long weatherTs() { return sp.getLong("weather_ts", 0); }
    public void weather(String json) {
        sp.edit().putString("weather", json).putLong("weather_ts", System.currentTimeMillis()).apply();
    }
}
