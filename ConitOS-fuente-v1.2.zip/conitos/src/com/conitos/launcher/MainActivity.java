package com.conitos.launcher;

import android.Manifest;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * ConitOS Launcher: pantalla principal estilo glassmorphism con reloj, clima,
 * botón de voz protagonista, accesos rápidos editables e intro de arranque.
 */
public class MainActivity extends Activity {

    private Prefs prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Vistas
    private ImageView bgImage, weatherIcon, micButton, settingsBtn, introLogo, voiceMic;
    private View scrim, micRing, introBeam, voicePanel;
    private TextView clockText, dateText, tempText, cityText, detailText, micHint,
            voiceStatus, voiceResult, voiceResponse;
    private LinearLayout weatherCard, quickRow;
    private FrameLayout voiceOverlay, introOverlay, micWrap;
    private EditText voiceEdit;
    private Button voiceSend;
    private ViewGroup rootLayout;

    // Fondo animado (GIF / MP4)
    private GifBackgroundView gifView;
    private VideoBackgroundView videoView;

    // Estado
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private ValueAnimator pulse;
    private int lastHour = -1;
    private int lastBgVersion = -1;
    private boolean introDone = true;
    private static boolean coldStart = true;

    private final SimpleDateFormat timeFmt = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final SimpleDateFormat timeFmtSec = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEEE, d 'de' MMMM", new Locale("es", "AR"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        setContentView(R.layout.activity_main);
        hideSystemBars();
        bindViews();
        applyPalette();
        loadBackground();
        updateClock();
        startClock();
        refreshWeather(false);
        buildQuickRow();
        if (prefs.anim() && coldStart) runIntro();
        coldStart = false;
        // TTS: se inicializa siempre (async) para que también funcione "Probar voz" en Ajustes
        Tts.get().ensureStarted(getApplicationContext(), prefs);
        handler.postDelayed(() -> micButton.requestFocus(), 300);
    }

    private void hideSystemBars() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        } catch (Throwable ignored) {}
    }

    private void bindViews() {
        bgImage = findViewById(R.id.bgImage);
        rootLayout = (ViewGroup) bgImage.getParent();   // raíz del home: ahí se cuelga el GIF/video
        scrim = findViewById(R.id.scrim);
        clockText = findViewById(R.id.clockText);
        dateText = findViewById(R.id.dateText);
        weatherCard = findViewById(R.id.weatherCard);
        weatherIcon = findViewById(R.id.weatherIcon);
        tempText = findViewById(R.id.tempText);
        cityText = findViewById(R.id.cityText);
        detailText = findViewById(R.id.detailText);
        micWrap = findViewById(R.id.micWrap);
        micRing = findViewById(R.id.micRing);
        // El anillo de pulso escala por fuera de su contenedor: sin recorte para no verse cortado
        micWrap.setClipChildren(false);
        micWrap.setClipToPadding(false);
        micButton = findViewById(R.id.micButton);
        micHint = findViewById(R.id.micHint);
        quickRow = findViewById(R.id.quickRow);
        settingsBtn = findViewById(R.id.settingsBtn);
        voiceOverlay = findViewById(R.id.voiceOverlay);
        voicePanel = findViewById(R.id.voicePanel);
        voiceMic = findViewById(R.id.voiceMic);
        voiceStatus = findViewById(R.id.voiceStatus);
        voiceResult = findViewById(R.id.voiceResult);
        voiceResponse = findViewById(R.id.voiceResponse);
        voiceEdit = findViewById(R.id.voiceEdit);
        voiceSend = findViewById(R.id.voiceSend);
        introOverlay = findViewById(R.id.introOverlay);
        introLogo = findViewById(R.id.introLogo);
        introBeam = findViewById(R.id.introBeam);

        micButton.setOnClickListener(v -> onMicPressed());
        micWrap.setOnLongClickListener(v -> { startActivity(new Intent(this, SettingsActivity.class)); return true; });
        settingsBtn.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        voiceSend.setOnClickListener(v -> submitTyped());
        cityText.setText(prefs.city());
    }

    // ---------------------------------------------------------------- reloj

    private void startClock() {
        Runnable tick = new Runnable() {
            @Override
            public void run() {
                updateClock();
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(tick);
    }

    private void updateClock() {
        Date now = new Date();
        clockText.setText((prefs.seconds() ? timeFmtSec : timeFmt).format(now));
        String d = dateFmt.format(now);
        dateText.setText(Character.toUpperCase(d.charAt(0)) + d.substring(1));

        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h != lastHour) {
            lastHour = h;
            applyPalette();
        }
    }

    /** Modo claro / oscuro automático según la hora (08–20 claro). */
    private boolean isNightNow() {
        String m = prefs.nightMode();
        if ("dark".equals(m)) return true;
        if ("light".equals(m)) return false;
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h < 8 || h >= 20;
    }

    // ------------------------------------------------------------- apariencia

    private void applyPalette() {
        boolean night = isNightNow();
        int textColor = night ? 0xFFF2F5FA : 0xFF14161C;
        int subColor = night ? 0xB3FFFFFF : 0x99000000;
        int accent = UiUtil.accentColor(this, prefs);
        int glass = UiUtil.glassArgb(this, prefs, night);

        clockText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, prefs.clockSize());
        clockText.setTextColor(textColor);
        dateText.setTextColor(subColor);
        micHint.setTextColor(subColor);
        micHint.setText("¿En qué puedo ayudarte?");
        tempText.setTextColor(textColor);
        cityText.setTextColor(subColor);
        detailText.setTextColor(subColor);
        voiceStatus.setTextColor(textColor);
        voiceResult.setTextColor(subColor);
        voiceResponse.setTextColor(textColor);
        scrim.setAlpha(night ? 0.55f : 0.35f);

        weatherCard.setBackground(UiUtil.glass(this, glass, 26f));
        voicePanel.setBackground(UiUtil.glass(this, glass, 28f));

        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.TRANSPARENT);
        ring.setStroke(UiUtil.dp(this, 3f), accent);
        micRing.setBackground(ring);

        micButton.setBackground(UiUtil.focusSelector(
                UiUtil.glassOval(this, glass),
                UiUtil.glassOvalFocused(this, glass, accent)));
        micButton.setColorFilter(accent);
        weatherIcon.setColorFilter(accent);
        voiceMic.setColorFilter(accent);
        settingsBtn.setColorFilter(night ? 0xAAFFFFFF : 0x99000000);
        voiceSend.setTextColor(accent);

        // Re-estiliza accesos rápidos existentes
        for (int i = 0; i < quickRow.getChildCount(); i++) {
            View item = quickRow.getChildAt(i);
            if (item instanceof ViewGroup && ((ViewGroup) item).getChildCount() > 0) {
                View circle = ((ViewGroup) item).getChildAt(0);
                circle.setBackground(UiUtil.focusSelector(
                        UiUtil.glassOval(this, glass),
                        UiUtil.glassOvalFocused(this, glass, accent)));
                circle.setOnFocusChangeListener((v, f) -> v.animate()
                        .scaleX(f ? 1.07f : 1f).scaleY(f ? 1.07f : 1f).setDuration(130).start());
                if (((ViewGroup) item).getChildCount() > 1) {
                    ((TextView) ((ViewGroup) item).getChildAt(1)).setTextColor(subColor);
                }
            }
        }
    }

    private void loadBackground() {
        int v = prefs.bgVersion();
        lastBgVersion = v;

        // Limpiar fondo animado anterior
        if (gifView != null) { rootLayout.removeView(gifView); gifView = null; }
        if (videoView != null) { videoView.release(); rootLayout.removeView(videoView); videoView = null; }

        File mp4 = new File(getFilesDir(), "bg.mp4");
        File gif = new File(getFilesDir(), "bg.gif");
        File jpg = new File(getFilesDir(), "bg.jpg");

        // 1) Video MP4 en bucle, mudo, centerCrop
        if (v > 0 && mp4.exists()) {
            videoView = new VideoBackgroundView(this, mp4.getAbsolutePath());
            bgImage.setVisibility(View.GONE);
            rootLayout.addView(videoView, 0, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return;
        }

        // 2) GIF animado en bucle
        File imgFile = null;
        if (v > 0 && gif.exists()) {
            GifBackgroundView g = new GifBackgroundView(this, gif);
            if (g.isOk()) {
                gifView = g;
                bgImage.setVisibility(View.GONE);
                rootLayout.addView(gifView, 0, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                return;
            }
            imgFile = gif;   // GIF raro/estático: se muestra el primer frame como imagen
        } else if (v > 0 && jpg.exists()) {
            imgFile = jpg;
        }

        // 3) Imagen fija con desenfoque (igual que siempre)
        if (imgFile != null) {
            Bitmap bmp = decodeSampled(imgFile, 1280);
            if (bmp != null) {
                bgImage.setVisibility(View.VISIBLE);
                BlurUtil.apply(bgImage, bmp, prefs.blur());
            } else {
                bgImage.setVisibility(View.GONE);
            }
        } else {
            bgImage.setVisibility(View.GONE);
        }
    }

    private Bitmap decodeSampled(File f, int maxW) {
        try {
            byte[] data = readAll(f);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = Math.max(1, o.outWidth / maxW);
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
        } catch (Throwable t) {
            return null;
        }
    }

    private byte[] readAll(File f) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            return bos.toByteArray();
        } catch (Throwable t) {
            return new byte[0];
        }
    }

    // ---------------------------------------------------------------- intro

    private void runIntro() {
        introDone = false;
        introOverlay.setVisibility(View.VISIBLE);
        introOverlay.setAlpha(1f);
        introLogo.setAlpha(0f);
        introLogo.setScaleX(0.92f);
        introLogo.setScaleY(0.92f);

        ObjectAnimator a1 = ObjectAnimator.ofFloat(introLogo, "alpha", 0f, 1f);
        ObjectAnimator a2 = ObjectAnimator.ofFloat(introLogo, "scaleX", 0.92f, 1f);
        ObjectAnimator a3 = ObjectAnimator.ofFloat(introLogo, "scaleY", 0.92f, 1f);
        AnimatorSet s = new AnimatorSet();
        s.playTogether(a1, a2, a3);
        s.setDuration(700);
        s.setInterpolator(new AccelerateDecelerateInterpolator());
        s.start();

        ValueAnimator beam = ValueAnimator.ofFloat(0f, 1f, 0f, 1f, 0f);
        beam.setDuration(1600);
        beam.setStartDelay(300);
        beam.addUpdateListener(a -> introBeam.setAlpha(((float) a.getAnimatedValue()) * 0.9f));
        beam.start();

        handler.postDelayed(() -> introOverlay.animate()
                .alpha(0f).setDuration(500)
                .withEndAction(() -> { introOverlay.setVisibility(View.GONE); introDone = true; })
                .start(), 2000);
    }

    // ---------------------------------------------------------- accesos rápidos

    private void buildQuickRow() {
        quickRow.removeAllViews();
        // Sin recorte: al enfocar, el círculo crece por fuera de sus límites sin cortarse
        quickRow.setClipChildren(false);
        quickRow.setClipToPadding(false);
        List<String> slots = prefs.slots();
        if (slots == null) {
            slots = AppRepository.resolveDefaults(this);
            prefs.slots(slots);
        }
        int size = UiUtil.dp(this, prefs.iconSize());
        boolean night = isNightNow();
        int glass = UiUtil.glassArgb(this, prefs, night);
        int accent = UiUtil.accentColor(this, prefs);
        int subColor = night ? 0xB3FFFFFF : 0x99000000;

        for (int i = 0; i < slots.size(); i++) {
            final int idx = i;
            AppRepository.AppInfo a = AppRepository.fromSlot(this, slots.get(i));

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(android.view.Gravity.CENTER);
            item.setClipChildren(false);   // clave: el círculo enfocado no se recorta al escalar
            item.setClipToPadding(false);
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            itemLp.setMargins(UiUtil.dp(this, 9f), 0, UiUtil.dp(this, 9f), 0);

            FrameLayout circle = new FrameLayout(this);
            circle.setFocusable(true);
            circle.setClickable(true);
            circle.setBackground(UiUtil.focusSelector(
                    UiUtil.glassOval(this, glass),
                    UiUtil.glassOvalFocused(this, glass, accent)));
            circle.setOnClickListener(v -> {
                if (a != null) AppRepository.launch(this, a);
                else openPicker(idx);
            });
            circle.setOnLongClickListener(v -> { openPicker(idx); return true; });
            circle.setOnFocusChangeListener((v, f) -> v.animate()
                    .scaleX(f ? 1.07f : 1f).scaleY(f ? 1.07f : 1f).setDuration(130).start());

            ImageView iv = new ImageView(this);
            FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(
                    Math.round(size * 0.62f), Math.round(size * 0.62f), android.view.Gravity.CENTER);
            if (a != null && a.icon != null) {
                iv.setImageDrawable(a.icon);
            } else {
                iv.setImageResource(R.drawable.ic_add);
                iv.setColorFilter(0x88FFFFFF);
            }
            circle.addView(iv, ilp);
            item.addView(circle, new LinearLayout.LayoutParams(size, size));

            TextView tv = new TextView(this);
            tv.setText(a != null ? (a.label.length() > 14 ? a.label.substring(0, 13) + "…" : a.label) : "Elegir");
            tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11);
            tv.setTextColor(subColor);
            tv.setGravity(android.view.Gravity.CENTER);
            tv.setMaxLines(1);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.topMargin = UiUtil.dp(this, 5f);
            tlp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
            item.addView(tv, tlp);

            quickRow.addView(item, itemLp);
        }
    }

    private void openPicker(int idx) {
        List<AppRepository.AppInfo> apps = AppRepository.list(this);
        if (apps.isEmpty()) { UiUtil.toast(this, "No hay aplicaciones instaladas"); return; }
        ListView lv = new ListView(this);
        lv.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() { return apps.size(); }
            @Override
            public Object getItem(int position) { return apps.get(position); }
            @Override
            public long getItemId(int position) { return position; }
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);
                row.setPadding(UiUtil.dp(MainActivity.this, 16f), UiUtil.dp(MainActivity.this, 8f),
                        UiUtil.dp(MainActivity.this, 16f), UiUtil.dp(MainActivity.this, 8f));
                AppRepository.AppInfo a = apps.get(position);
                ImageView ic = new ImageView(MainActivity.this);
                ic.setLayoutParams(new LinearLayout.LayoutParams(UiUtil.dp(MainActivity.this, 34f), UiUtil.dp(MainActivity.this, 34f)));
                if (a.icon != null) ic.setImageDrawable(a.icon);
                row.addView(ic);
                TextView t = new TextView(MainActivity.this);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                tlp.leftMargin = UiUtil.dp(MainActivity.this, 14f);
                t.setText(a.label);
                t.setTextColor(0xFFF2F5FA);
                t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15);
                row.addView(t, tlp);
                return row;
            }
        });
        android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Elegir aplicación")
                .setView(lv)
                .setNegativeButton("Cancelar", null)
                .create();
        lv.setOnItemClickListener((p, v, pos, id) -> {
            List<String> slots = prefs.slots();
            if (slots == null) slots = new ArrayList<>();
            while (slots.size() <= idx) slots.add("");
            slots.set(idx, AppRepository.slotKey(apps.get(pos)));
            prefs.slots(slots);
            dlg.dismiss();
            buildQuickRow();
        });
        dlg.show();
    }

    // ------------------------------------------------------------------ voz

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void onMicPressed() {
        if (!hasMicPermission()) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 101);
            return;
        }
        openVoicePanel();
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openVoicePanel();
                startListening();
            } else {
                openVoicePanelTyped("Necesito permiso de micrófono para escucharte. Mientras tanto, podés escribir:");
            }
        }
    }

    private void openVoicePanel() {
        voiceOverlay.setVisibility(View.VISIBLE);
        voiceOverlay.setAlpha(0f);
        voiceOverlay.animate().alpha(1f).setDuration(180).start();
        voicePanel.setTranslationY(40f);
        voicePanel.setAlpha(0f);
        voicePanel.animate().translationY(0f).alpha(1f).setDuration(220).start();

        voiceStatus.setText("Escuchando…");
        voiceResult.setVisibility(View.GONE);
        voiceResponse.setVisibility(View.GONE);
        voiceEdit.setVisibility(View.GONE);
        voiceSend.setVisibility(View.GONE);
        startMicPulse();
    }

    private void openVoicePanelTyped(String msg) {
        openVoicePanel();
        stopMicPulse();
        micButton.setScaleX(1f);
        micButton.setScaleY(1f);
        voiceStatus.setText(msg);
        voiceEdit.setVisibility(View.VISIBLE);
        voiceSend.setVisibility(View.VISIBLE);
        voiceEdit.requestFocus();
    }

    private void startListening() {
        if (listening) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            openVoicePanelTyped("No hay motor de voz en este equipo. Podés escribir tu comando:");
            return;
        }
        try {
            if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new VoiceListener());
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-AR");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            recognizer.startListening(i);
            listening = true;
        } catch (Throwable t) {
            openVoicePanelTyped("La voz no está disponible. Escribí tu comando:");
        }
    }

    private void startMicPulse() {
        micRing.setVisibility(View.VISIBLE);
        if (!prefs.anim()) {
            micRing.setAlpha(0.5f);
            return;
        }
        stopMicPulse();
        pulse = ValueAnimator.ofFloat(0f, 1f);
        pulse.setDuration(1400);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.RESTART);
        pulse.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            micRing.setScaleX(1f + f * 0.45f);
            micRing.setScaleY(1f + f * 0.45f);
            micRing.setAlpha(0.6f * (1f - f));
        });
        pulse.start();
    }

    private void stopMicPulse() {
        if (pulse != null) { pulse.cancel(); pulse = null; }
        micRing.setAlpha(0f);
    }

    private void closeVoicePanel() {
        stopMicPulse();
        listening = false;
        if (recognizer != null) { try { recognizer.stopListening(); } catch (Throwable ignored) {} }
        voiceOverlay.animate().alpha(0f).setDuration(180)
                .withEndAction(() -> voiceOverlay.setVisibility(View.GONE)).start();
    }

    private void handleCommand(String text) {
        if (TextUtils.isEmpty(text)) text = "";
        listening = false;
        stopMicPulse();
        voiceResult.setText("“" + text + "”");
        voiceResult.setVisibility(View.VISIBLE);

        CommandParser.Cmd cmd = CommandParser.parse(text);
        String resp = execute(cmd);
        if (resp != null && !resp.isEmpty()) {
            voiceResponse.setText(resp);
            voiceResponse.setVisibility(View.VISIBLE);
            speak(resp);
            handler.postDelayed(this::closeVoicePanelIfShown, 5000);
        } else {
            handler.postDelayed(this::closeVoicePanelIfShown, 800);
        }
    }

    private void closeVoicePanelIfShown() {
        if (voiceOverlay.getVisibility() == View.VISIBLE) closeVoicePanel();
    }

    private void submitTyped() {
        handleCommand(voiceEdit.getText().toString());
    }

    /** Ejecuta un comando y devuelve la respuesta hablada/texto. */
    private String execute(CommandParser.Cmd cmd) {
        switch (cmd.type) {
            case CommandParser.T_TIME: {
                Calendar c = Calendar.getInstance();
                return String.format(Locale.US, "Son las %d:%02d",
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
            }
            case CommandParser.T_WEATHER:
                return weatherAnswer();
            case CommandParser.T_VOL_UP:
                try {
                    AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                    return "Subiendo el volumen.";
                } catch (Throwable t) { return "No pude ajustar el volumen."; }
            case CommandParser.T_VOL_DOWN:
                try {
                    AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                    return "Bajando el volumen.";
                } catch (Throwable t) { return "No pude ajustar el volumen."; }
            case CommandParser.T_MUTE:
                try {
                    AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI);
                    return "Silencio alternado.";
                } catch (Throwable t) { return "No pude alternar el silencio."; }
            case CommandParser.T_BRIGHT_UP:
                return changeBrightness(+20);
            case CommandParser.T_BRIGHT_DOWN:
                return changeBrightness(-20);
            case CommandParser.T_REBOOT:
                return tryReboot();
            case CommandParser.T_POWER:
                return tryPowerOff();
            case CommandParser.T_SETTINGS:
                try {
                    startActivity(new Intent(Settings.ACTION_SETTINGS)
                            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    return "Abriendo configuración.";
                } catch (Throwable t) { return "No pude abrir la configuración."; }
            case CommandParser.T_LAUNCH:
                return launchAnswer(cmd.arg);
            case CommandParser.T_HOME:
                return null;
            default:
                return "No entendí. Probá con: \"Abrí YouTube\", \"Subí el volumen\" o \"¿Qué hora es?\".";
        }
    }

    private String weatherAnswer() {
        try {
            String cached = prefs.weather();
            if (cached != null) {
                JSONObject cur = new JSONObject(cached).getJSONObject("current");
                double t = cur.optDouble("temperature_2m", Double.NaN);
                int code = cur.optInt("weather_code", -1);
                if (!Double.isNaN(t)) {
                    return String.format(Locale.US, "En %s hay %.0f grados, %s.", prefs.city(), t, WeatherService.textFor(code));
                }
            }
        } catch (Throwable ignored) {}
        refreshWeather(true);
        return "Consultando el clima…";
    }

    private String launchAnswer(String arg) {
        if (arg == null || arg.isEmpty()) return "¿Qué aplicación querés abrir?";
        AppRepository.AppInfo a = null;
        if (arg.startsWith("com.")) a = AppRepository.byPackage(this, arg);
        if (a == null) a = AppRepository.fuzzy(AppRepository.list(this), arg);
        if (a == null) return "No encontré la aplicación \"" + arg + "\" en este equipo.";
        AppRepository.launch(this, a);
        return "Abriendo " + a.label + ".";
    }

    private String changeBrightness(int deltaPct) {
        try {
            if (!Settings.System.canWrite(this)) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            android.net.Uri.parse("package:" + getPackageName()))
                            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Throwable ignored) {}
                return "Concedeme permiso para modificar el brillo y volvé a probar.";
            }
            int cur = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
            int step = Math.round(255f * deltaPct / 100f);
            int next = Math.max(10, Math.min(255, cur + step));
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, next);
            return deltaPct > 0 ? "Subiendo el brillo." : "Bajando el brillo.";
        } catch (Throwable t) {
            return "Este equipo no permite cambiar el brillo desde aplicaciones.";
        }
    }

    private String tryReboot() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            pm.reboot("ConitOS");
            return "Reiniciando…";
        } catch (Throwable ignored) {}
        try {
            Runtime.getRuntime().exec(new String[]{"reboot"});
            return "Reiniciando…";
        } catch (Throwable ignored) {}
        return "Necesito permisos de sistema para reiniciar. Podés instalar ConitOS como app de sistema (ver README).";
    }

    private String tryPowerOff() {
        try {
            Runtime.getRuntime().exec(new String[]{"reboot", "-p"});
            return "Apagando…";
        } catch (Throwable ignored) {}
        return "Necesito permisos de sistema para apagar el equipo. Con el control: mantén presionado el botón de encendido.";
    }

    private void speak(String s) {
        if (!prefs.tts()) return;
        Tts.get().speak(s);
    }

    // ---------------------------------------------------------------- clima

    private void refreshWeather(boolean force) {
        WeatherService.fetchAsync(prefs, force, cur -> {
            if (cur == null) {
                tempText.setText("--°");
                detailText.setText("Sin datos de clima · verificá la conexión");
                return;
            }
            double t = cur.optDouble("temperature_2m", Double.NaN);
            int hum = cur.optInt("relative_humidity_2m", -1);
            double wind = cur.optDouble("wind_speed_10m", Double.NaN);
            int code = cur.optInt("weather_code", -1);
            tempText.setText(Double.isNaN(t) ? "--°" : String.format(Locale.US, "%.0f°", t));
            detailText.setText(String.format(Locale.US, "Humedad %d%% · Viento %.0f km/h",
                    hum, Double.isNaN(wind) ? 0 : wind));
            weatherIcon.setImageResource(WeatherService.iconFor(code, isNightNow()));
            weatherIcon.setColorFilter(UiUtil.accentColor(this, prefs));
        });
    }

    // ------------------------------------------------------------- ciclo vida

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemBars();
        lastHour = -1;
        updateClock();
        cityText.setText(prefs.city());
        if (prefs.bgVersion() != lastBgVersion) loadBackground();
        refreshWeather(false);
        buildQuickRow();
        applyPalette();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (listening) closeVoicePanel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { try { recognizer.destroy(); } catch (Throwable ignored) {} }
        // El TTS es singleton (también lo usa Ajustes): no se apaga acá
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int k = event.getKeyCode();
            // Botón de micrófono del control remoto o búsqueda
            if (k == KeyEvent.KEYCODE_VOICE_ASSIST || k == KeyEvent.KEYCODE_ASSIST || k == KeyEvent.KEYCODE_SEARCH) {
                if (!introDone) return true;
                if (!hasMicPermission()) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 101);
                } else {
                    openVoicePanel();
                    startListening();
                }
                return true;
            }
            if (k == KeyEvent.KEYCODE_BACK) {
                if (voiceOverlay.getVisibility() == View.VISIBLE) {
                    closeVoicePanel();
                } else if (introOverlay.getVisibility() == View.VISIBLE) {
                    // ignorar durante la intro
                } else {
                    moveTaskToBack(true);
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    // -------------------------------------------------------- listener de voz

    private class VoiceListener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle params) { voiceStatus.setText("Escuchando…"); }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) {
            float s = 1f + Math.min(0.5f, Math.max(0f, (rmsdB + 2f) / 12f));
            micButton.setScaleX(s);
            micButton.setScaleY(s);
        }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { voiceStatus.setText("Procesando…"); }
        @Override public void onError(int error) {
            listening = false;
            stopMicPulse();
            micButton.setScaleX(1f);
            micButton.setScaleY(1f);
            String msg;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    msg = "No te escuché. Probá de nuevo.";
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    msg = "Falta el permiso de micrófono.";
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    msg = "Error de red para reconocer voz.";
                    break;
                default:
                    msg = "No pude reconocer el audio (código " + error + ").";
            }
            voiceStatus.setText(msg);
            handler.postDelayed(MainActivity.this::closeVoicePanelIfShown, 2500);
        }
        @Override public void onResults(Bundle results) {
            listening = false;
            stopMicPulse();
            micButton.setScaleX(1f);
            micButton.setScaleY(1f);
            ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            handleCommand(list != null && !list.isEmpty() ? list.get(0) : "");
        }
        @Override public void onPartialResults(Bundle partialResults) {
            ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) {
                voiceResult.setText("“" + list.get(0) + "”");
                voiceResult.setVisibility(View.VISIBLE);
            }
        }
        @Override public void onEvent(int eventType, Bundle params) { }
    }
}
