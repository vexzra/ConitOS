#!/bin/bash
# Build de ConitOS Launcher sin Gradle: aapt2 -> javac -> d8 -> zip -> zipalign -> apksigner
set -euo pipefail

SDK=/home/z/sdk
JAVA_HOME=/home/z/sdk/jdk-17.0.21+9
export PATH="$JAVA_HOME/bin:$PATH"
BT=$SDK/build-tools/34.0.0
PLAT=$SDK/platforms/android-34/android.jar
PROJ=/home/z/my-project/conitos
OUT=$PROJ/build
APK=ConitOS-Launcher-v1.2.apk

rm -rf "$OUT"
mkdir -p "$OUT/gen" "$OUT/classes" "$OUT/dex"

echo "== 1) aapt2 compile =="
"$BT/aapt2" compile --dir "$PROJ/res" -o "$OUT/res.zip"

echo "== 2) aapt2 link =="
"$BT/aapt2" link -o "$OUT/base.apk" -I "$PLAT" \
  --manifest "$PROJ/AndroidManifest.xml" \
  -R "$OUT/res.zip" \
  --java "$OUT/gen" \
  --min-sdk-version 24 --target-sdk-version 34 \
  --version-code 3 --version-name 1.2 \
  --auto-add-overlay

echo "== 3) javac =="
find "$PROJ/src" "$OUT/gen" -name "*.java" > "$OUT/sources.txt"
javac -source 8 -target 8 -nowarn -encoding UTF-8 -Xlint:none \
  -classpath "$PLAT" \
  -d "$OUT/classes" @"$OUT/sources.txt" 2>&1 | grep -v "^Note:" || true

echo "== 4) d8 (dex) =="
jar cf "$OUT/classes.jar" -C "$OUT/classes" .
"$BT/d8" --release --lib "$PLAT" --min-api 24 --output "$OUT/dex" "$OUT/classes.jar"

echo "== 5) empaquetado =="
(cd "$OUT/dex" && zip -q "$OUT/base.apk" classes.dex)

echo "== 6) zipalign =="
"$BT/zipalign" -f 4 "$OUT/base.apk" "$OUT/aligned.apk"

echo "== 7) keystore + firma =="
if [ ! -f "$PROJ/conitos.jks" ]; then
  keytool -genkeypair -v -keystore "$PROJ/conitos.jks" -alias conitos \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass conitos2026 -keypass conitos2026 \
    -dname "CN=ConitOS, OU=Home, O=ConitOS, L=Salta, ST=Salta, C=AR" 2>&1 | tail -1
fi
"$BT/apksigner" sign --ks "$PROJ/conitos.jks" --ks-key-alias conitos \
  --ks-pass pass:conitos2026 --key-pass pass:conitos2026 \
  --out "$PROJ/$APK" "$OUT/aligned.apk"

echo "== 8) verificación =="
"$BT/apksigner" verify --print-certs "$PROJ/$APK" | head -4
"$BT/aapt2" dump badging "$PROJ/$APK" | head -8
ls -lh "$PROJ/$APK"
echo "BUILD OK: $PROJ/$APK"
